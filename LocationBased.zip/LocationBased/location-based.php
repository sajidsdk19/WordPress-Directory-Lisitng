<?php
/*
Plugin Name: Directorist Location Filter
Description: Adds a location filter to the Directorist listings admin page.
Version: 1.0
Author: Sajid Khan
*/

// Add a custom location filter dropdown to the Directorist listings admin page
function add_directorist_location_filter() {
    global $wpdb;

    // Fetch available locations from the database
    $locations = $wpdb->get_results("SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE meta_key = '_address'");

    // Check if we are on the Directorist listings admin page
    $screen = get_current_screen();
    if ($screen->post_type !== 'at_biz_dir') {
        return;
    }

    // Count the occurrences of each location
    $location_counts = array();
    foreach ($locations as $location) {
        // Extract only the location name (assuming it's the second part of the meta value)
        $location_name = explode(',', $location->meta_value)[1];
        
        if (
            stripos($location_name, 'United States') === false && 
            ctype_alpha(str_replace(' ', '', $location_name)) && 
            stripos($location_name, 'Not Available') === false && 
            stripos($location_name, 'Information not Available') === false
        ) {
            if (isset($location_counts[$location_name])) {
                $location_counts[$location_name]++;
            } else {
                $location_counts[$location_name] = 1;
            }
        }
    }

    // Filter out locations with a count of 1 or less
    $filtered_locations = array_filter($location_counts, function($count) {
        return $count > 1;
    });

    // Sort locations by count in descending order
    arsort($filtered_locations);

    echo '<select name="directorist_location_filter">';
    echo '<option value="">' . __('All Locations', 'directorist') . '</option>';

    $selected_location = isset($_GET['directorist_location_filter']) ? $_GET['directorist_location_filter'] : '';

    foreach ($filtered_locations as $location_name => $count) {
        $selected = $location_name === $selected_location ? 'selected="selected"' : '';
        echo '<option value="' . esc_attr($location_name) . '" ' . $selected . '>' . esc_html($location_name) . '</option>';
    }

    echo '</select>';
}
add_action('restrict_manage_posts', 'add_directorist_location_filter');

// Modify the query to filter listings by location
function filter_directorist_listings_by_location($query) {
    global $pagenow;

    if (is_admin() && $pagenow === 'edit.php' && isset($_GET['directorist_location_filter']) && !empty($_GET['directorist_location_filter']) && $query->query_vars['post_type'] == 'at_biz_dir') {
        $query->set('meta_query', array(
            array(
                'key' => '_address',
                'value' => sanitize_text_field($_GET['directorist_location_filter']),
                'compare' => 'LIKE'
            )
        ));
    }
}
add_action('pre_get_posts', 'filter_directorist_listings_by_location');
?>
