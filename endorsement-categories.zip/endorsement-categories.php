<?php
/*
Plugin Name: Endorsement Categories
Description: Adds endorsement categories to all directory listings on the front end.
Version: 1.0
Author: Your Name
*/

// Enqueue jQuery if not already loaded
function endorsement_enqueue_scripts() {
    if (!wp_script_is('jquery')) {
        wp_enqueue_script('jquery');
    }
}
add_action('wp_enqueue_scripts', 'endorsement_enqueue_scripts');

// Handle AJAX request
function update_endorsement() {
    if (!isset($_POST['category']) || !isset($_POST['voteChange'])) {
        wp_send_json_error();
    }

    $category = sanitize_text_field($_POST['category']);
    $voteChange = intval($_POST['voteChange']);
    
    // Retrieve the current vote count from the database
    $current_votes = get_option('endorsement_' . $category, 0);

    // Update the vote count
    $new_votes = max(0, $current_votes + $voteChange);

    // Save the new vote count back to the database
    update_option('endorsement_' . $category, $new_votes);

    wp_send_json_success(['newVoteCount' => $new_votes]);
}

add_action('wp_ajax_update_endorsement', 'update_endorsement');
add_action('wp_ajax_nopriv_update_endorsement', 'update_endorsement');

// Shortcode function
function endorsement_categories_shortcode() {
    ob_start();
    ?>
    <div id="categories">
        <div class="category" data-category="coaching">Coaching <span class="vote-count"><?php echo get_option('endorsement_coaching', 0); ?></span></div>
        <div class="category" data-category="facilities">Facilities <span class="vote-count"><?php echo get_option('endorsement_facilities', 0); ?></span></div>
        <!-- Add more categories as needed -->
    </div>
    <style>
        .category {
            display: inline-block;
            padding: 10px;
            border: 1px dotted gray;
            margin: 5px;
            cursor: pointer;
            text-align: center;
        }
        .voted {
            border-color: green;
        }
    </style>
    <script>
        jQuery(document).ready(function($) {
            $('.category').click(function() {
                var categoryElement = $(this);
                var category = categoryElement.data('category');
                var voted = categoryElement.hasClass('voted');
                var voteChange = voted ? -1 : 1;

                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    method: 'POST',
                    data: {
                        action: 'update_endorsement',
                        category: category,
                        voteChange: voteChange
                    },
                    success: function(response) {
                        if (response.success) {
                            var newVoteCount = response.data.newVoteCount;
                            categoryElement.find('.vote-count').text(newVoteCount);
                            categoryElement.toggleClass('voted');
                        } else {
                            alert('Error updating endorsement');
                        }
                    }
                });
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('endorsement_categories', 'endorsement_categories_shortcode');

// Display shortcode on all directory listings
function add_endorsement_categories_to_directory_listings($content) {
    if (is_singular('directory_listing')) { // Replace 'directory_listing' with the actual post type for directory listings
        $content .= do_shortcode('[endorsement_categories]');
    }
    return $content;
}
add_filter('the_content', 'add_endorsement_categories_to_directory_listings');
